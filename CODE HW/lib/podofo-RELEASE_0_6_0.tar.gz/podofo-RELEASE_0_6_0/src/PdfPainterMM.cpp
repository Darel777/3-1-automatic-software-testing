#include "PdfPainterMM.h"

namespace PoDoFo {

/* Defining the virtual destructor here rather than in the header
 * ensures that the vtable gets output correctly by all compilers.
 */
PdfPainterMM::~PdfPainterMM()
{
}

};
