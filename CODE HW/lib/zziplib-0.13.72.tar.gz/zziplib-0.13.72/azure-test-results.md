# master branch tests for zziplib on Azure Pipelines

[(master)](https://github.com/gdraheim/zziplib/tree/master): [![Build Status](https://dev.azure.com/gdraheim/gdraheim/_apis/build/status/gdraheim.zziplib%20(1)?branchName=master)](https://dev.azure.com/gdraheim/gdraheim/_build/latest?definitionId=4&branchName=master)

[develop](https://github.com/gdraheim/zziplib/tree/develop): [![Build Status](https://dev.azure.com/gdraheim/gdraheim/_apis/build/status/gdraheim.zziplib%20(1)?branchName=develop)](https://dev.azure.com/gdraheim/gdraheim/_build/latest?definitionId=4&branchName=develop)


